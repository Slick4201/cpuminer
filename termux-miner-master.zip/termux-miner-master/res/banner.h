static void show_credits()
{
        printf(CL_LGR"   #####   ####   #    #  ##      ##  ###  ##      #  #####   #### \n");
        printf(CL_LGR"  #       #    #  #    #  # #    # #   #   # #     #  #      #    #\n");
        printf(CL_LGR"  #       #    #  #    #  #  #  #  #   #   #  #    #  #      #    #\n");
        printf(CL_LGR"  #       #####   #    #  #   ##   #   #   #   #   #  #####  #####\n");
        printf(CL_LGR"  #       #       #    #  #        #   #   #    #  #  #      # #\n");
        printf(CL_LGR"  #       #       #    #  #        #   #   #     # #  #      #  #\n");
        printf(CL_LGR"   #####  #        ####  ##        ## ###  #      ##  ###### #   ###\n");
	printf("\n");
        printf(CL_N"                           " CL_LYL2"++ MULTI ALGO ++"  CL_N"\n");
        printf("\n");
        printf(CL_LCY"              **"PACKAGE_NAME""CL_LYL" "PACKAGE_VERSION CL_LCY" by maribun20@github**\n");
        printf(CL_LYL"            Based Originaly from cpuminer-multi by tpruvot\n");
        printf(CL_N"######################################################################\n\n");
        printf(CL_LCY"  Author  "CL_LYL"           : Maribun20\n");
        printf(CL_LCY"  Telagram"CL_LYL"           : @Aminudin1 (Wong Fi Hung)\n");
        printf(CL_LCY"  Youtube Channel"CL_LYL"    : CHANNEL CRYPTO\n");
        printf(CL_LCY"  Git repo"CL_LYL"           : https:" "/" "/" "github.com" "/" "maribun20" "/" "termux-miner\n");
        printf(CL_LCY"  Original git repo"CL_LYL"  : https:" "/" "/" "github.com" "/" "tpruvot" "/" "cpuminer-multi\n");
        printf(CL_LCY"  DOGE donation addr"CL_LYL" : DN54hE4GVCyQ68jEvHMF1UBykdFBowcKCC (maribun20)\n");
        printf(CL_LCY"  BTC donation addr "CL_LYL" : 1FhDPLPpw18X4srecguG3MxJYe4a1JsZnd (tpruvot)\n");
        printf(CL_N"######################################################################\n");
}
